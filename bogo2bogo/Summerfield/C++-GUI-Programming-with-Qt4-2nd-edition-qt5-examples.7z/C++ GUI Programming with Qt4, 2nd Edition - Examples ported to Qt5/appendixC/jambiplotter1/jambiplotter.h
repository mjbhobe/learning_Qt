#include <QtWidgets>

#include "../plotter/plotter.h"
