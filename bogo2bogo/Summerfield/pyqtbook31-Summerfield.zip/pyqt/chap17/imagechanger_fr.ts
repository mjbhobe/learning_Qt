<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>HelpForm</name>
    <message>
        <location filename="helpform.py" line="24"/>
        <source>&amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="26"/>
        <source>&amp;Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="27"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helpform.py" line="51"/>
        <source>{} Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="imagechanger.pyw" line="59"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="61"/>
        <source>&amp;New...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="61"/>
        <source>Create an image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="64"/>
        <source>&amp;Open...</source>
        <translation>&amp;Ouvrez...</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="64"/>
        <source>Open an existing image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="67"/>
        <source>&amp;Save</source>
        <translation>&amp;Sauvegardez</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="67"/>
        <source>Save the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="70"/>
        <source>Save &amp;As...</source>
        <translation>S&amp;auvegardez comme...</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="70"/>
        <source>Save the image using a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="73"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="73"/>
        <source>Print the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="76"/>
        <source>&amp;Quit</source>
        <translation>Stoppe&amp;z</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="76"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="76"/>
        <source>Close the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="79"/>
        <source>&amp;Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="79"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="79"/>
        <source>Invert the image&apos;s colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="83"/>
        <source>Sw&amp;ap Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="83"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="83"/>
        <source>Swap the image&apos;s red and blue color components</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="88"/>
        <source>&amp;Zoom...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="88"/>
        <source>Alt+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="148"/>
        <source>Zoom the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="91"/>
        <source>&amp;Resize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="91"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="91"/>
        <source>Resize the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="95"/>
        <source>&amp;Unmirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="95"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="95"/>
        <source>Unmirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="99"/>
        <source>Mirror &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="99"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="99"/>
        <source>Horizontally mirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="106"/>
        <source>Mirror &amp;Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="106"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="106"/>
        <source>Vertically mirror the image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="113"/>
        <source>&amp;About Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="132"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="118"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="124"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edition</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="128"/>
        <source>&amp;Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="168"/>
        <source>Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="211"/>
        <source>Image Changer - Unsaved Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="211"/>
        <source>Save unsaved changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="237"/>
        <source>Image Changer - Unnamed[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="239"/>
        <source>Image Changer[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="280"/>
        <source>Created new image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="290"/>
        <source>Image Changer - Choose Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="323"/>
        <source>Failed to read %1</source>
        <translation type="obsolete">N&apos;a pas chargé %1</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="361"/>
        <source>Failed to save %1</source>
        <translation type="obsolete">N&apos;a pas sauvegardé %1</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="355"/>
        <source>Image Changer - Save Image</source>
        <translation>Image Changer -- Sauvegardé Fichiez</translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="390"/>
        <source>Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="390"/>
        <source>Uninverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="400"/>
        <source>Swapped Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="400"/>
        <source>Unswapped Red and Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="420"/>
        <source>Mirrored Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="420"/>
        <source>Unmirrored Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="431"/>
        <source>Mirrored Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="431"/>
        <source>Unmirrored Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="438"/>
        <source>Image Changer - Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="438"/>
        <source>Percent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="454"/>
        <source>Resized to the same size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="479"/>
        <source>About Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="502"/>
        <source>&lt;b&gt;Image Changer&lt;/b&gt; v %1
                &lt;p&gt;Copyright &amp;copy; 2007 Qtrac Ltd. 
                All rights reserved.
                &lt;p&gt;This application can be used to perform
                simple image manipulations.
                &lt;p&gt;Python %2 - Qt %3 - PyQt %4 
                on %5</source>
        <translation type="obsolete">&lt;b&gt;Image Changer&lt;/b&gt; v %1
                &lt;p&gt;Copyright &amp;copy; 2007 Qtrac Ltd. 
                Tous droits réservés.
                &lt;p&gt;This application can be used to perform
                simple image manipulations.
                &lt;p&gt;Python %2 - Qt %3 - PyQt %4 
                on %5
<byte value="x9"/></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="234"/>
        <source>Image Changer - {}[*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="355"/>
        <source>Image files ({})</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="310"/>
        <source>Failed to read {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="322"/>
        <source>Loaded {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="340"/>
        <source>Saved as {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="344"/>
        <source>Failed to save {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="463"/>
        <source>Resized to {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="imagechanger.pyw" line="479"/>
        <source>&lt;b&gt;Image Changer&lt;/b&gt; v {0}
                &lt;p&gt;Copyright &amp;copy; 2007-10 Qtrac Ltd. 
                All rights reserved.
                &lt;p&gt;This application can be used to perform
                simple image manipulations.
                &lt;p&gt;Python {1} - Qt {2} - PyQt {3} on {4}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewImageDlg</name>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Dense #7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Backward Diagonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Forward Diagonal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.py" line="24"/>
        <source>Diagonal Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="13"/>
        <source>Image Chooser - New Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="64"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="71"/>
        <source>&amp;Color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="81"/>
        <source>&amp;Brush pattern:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="91"/>
        <source>&amp;Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="101"/>
        <source>&amp;Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="newimagedlg.ui" line="136"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResizeDlg</name>
    <message>
        <location filename="resizedlg.py" line="21"/>
        <source>&amp;Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resizedlg.py" line="27"/>
        <source>&amp;Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="resizedlg.py" line="48"/>
        <source>Image Changer - Resize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="imagechanger.pyw" line="513"/>
        <source>Image Changer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
